/*
 *  dxl_debug.h
 *
 *  debug node op3
 *
 *  Created on: 2017. 2. 2.
 *      Author: Baram
 */

#ifndef DXL_DEBUG_H
#define DXL_DEBUG_H


#include "dxl.h"
#include "dxl_def.h"




#ifdef __cplusplus
 extern "C" {
#endif


#ifdef __cplusplus
}
#endif






void dxl_debug_init(void);
void dxl_debug_loop(void);

#endif
